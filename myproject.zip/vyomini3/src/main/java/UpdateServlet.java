import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/yt_demo");
            String query = "UPDATE addbookdetails SET name=? WHERE name=?";
            String uname = request.getParameter("name");
            String cname = request.getParameter("name2");

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, cname);
            ps.setString(2, uname);
            int result = ps.executeUpdate();
            if (result > 0) {
                response.sendRedirect("success.jsp");
            } else {
                response.sendRedirect("update.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    } // Closing bracket for doPost method
} // Closing bracket for UpdateServlet class